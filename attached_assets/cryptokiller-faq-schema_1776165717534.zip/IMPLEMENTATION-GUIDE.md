# CryptoKiller.org — FAQ Schema Implementation Guide
## AEO-Optimized JSON-LD for AI Overview & LLM Citations

Generated: April 14, 2026

---

## Overview

This package contains **6 JSON-LD schema blocks** with **44 FAQ question-answer pairs** 
structured for maximum AI citation likelihood across Google AI Overviews, Perplexity, ChatGPT, 
and Claude search.

### What's Included

| # | Page | FAQs | Author |
|---|------|------|--------|
| 1 | how-to-spot-crypto-scams | 8 | D. Ortiz |
| 2 | pig-butchering-scam | 7 | D. Ortiz |
| 3 | celebrity-crypto-scam | 7 | D. Ortiz |
| 4 | how-to-spot-a-deepfake | 7 | M. Webb |
| 5 | ai-crypto-trading-bot-scam | 7 | M. Webb |
| 6 | fake-trading-profits | 8 | D. Ortiz |

### Entity Graph Per Page (7 entities each)

```
Organization (@id: cryptokiller.org/#organization)
  └── publisher of ──►
WebSite (@id: cryptokiller.org/#website)
  └── isPartOf ──►
WebPage (@id: [page-url]/#webpage)
  └── breadcrumb ──►
BreadcrumbList (@id: [page-url]/#breadcrumb)
  └── mainEntityOfPage ──►
BlogPosting (@id: [page-url]/#article)
  ├── author ──► Person (@id: cryptokiller.org/#author-[name])
  ├── about ──► Wikidata-linked entities
  └── mentions ──► Government/org entities with sameAs
FAQPage (@id: [page-url]/#faq)
  └── mainEntity ──► Question[] with acceptedAnswer
```

---

## Implementation Instructions

### Option A: Direct HTML Injection (Recommended)

Each `.html` file contains a ready-to-paste `<script type="application/ld+json">` block.

1. Open the `.html` file for the target page
2. Copy the entire `<script>...</script>` block
3. Paste it into the page's `<head>` section
4. If the page already has JSON-LD schema, **replace** the existing block — don't stack multiple blocks

### Option B: Base44 / App Framework

If CryptoKiller runs on Base44 or a JS framework:

1. Open `cryptokiller-schema.json` (the master file)
2. Find the object matching the page URL
3. Inject the `schema` value as a JSON-LD script tag via your template/layout component

### Option C: WordPress (if migrated later)

Use SEOPress PRO, RankMath, or Yoast's custom schema field to paste each page's JSON-LD.

---

## Why This Works for AEO

### FAQPage Schema + AI Extraction

Google deprecated FAQPage **rich results** for non-gov/health sites in 2024. However:

- **AI Overviews** still parse FAQPage schema as a structured Q&A source
- **Perplexity** and **ChatGPT** extract FAQ schema as citation-ready answer blocks
- **Claude** reads JSON-LD during web fetch for direct answer synthesis

The FAQ questions are written in natural search query format (e.g., "What is a pig 
butchering scam in crypto?") — matching how users ask LLMs these exact questions.

### Entity-Linked BlogPosting

Every article's `about` and `mentions` properties link to Wikidata entities:

- `Cryptocurrency fraud` → Q113556378
- `Pig butchering scam` → Q113010974
- `Deepfake` → Q56272946
- `FBI` → Q8333
- `FTC` → Q548
- `SEC` → Q953944
- `Chainalysis` → Q108798498
- `Brookings Institution` → Q558629

This tells AI systems: "This article covers *this specific entity* and references 
*these specific authorities*." It's the structured equivalent of E-E-A-T signaling.

### Organization knowsAbout

The Organization entity declares 10 topical expertise areas that align with the site's 
actual content coverage. AI systems use this to evaluate whether CryptoKiller is a 
credible source for crypto scam queries — directly influencing citation probability.

---

## Validation

Test each page's schema after deployment:

1. **Rich Results Test**: https://search.google.com/test/rich-results
   - Paste the page URL after deployment
   - Expect: BlogPosting detected, FAQPage detected (no rich result preview — expected for non-gov sites)

2. **Schema.org Validator**: https://validator.schema.org
   - Paste the JSON-LD directly
   - Expect: 0 errors

3. **Google Search Console**: After deploying, monitor the Enhancements report for any schema errors.

---

## Maintenance

- **dateModified**: Update this field whenever you materially edit article content. 
  AI systems use this as a freshness signal. Don't change it for cosmetic edits.
- **New articles**: Follow this same pattern — BlogPosting + FAQPage in a single @graph, 
  with the same Organization and WebSite foundation.
- **New FAQ questions**: Add them to the FAQPage.mainEntity array. Only add questions 
  that are visibly displayed on the page (content-schema parity).
